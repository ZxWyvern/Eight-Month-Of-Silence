namespace Yumiwa.Domain
{
    /// <summary>
    /// Player settings per GDD §03/07 — all feel options must be togglable (anti motion-sickness).
    /// Head bob / camera shake / FOV boost are presentation toggles, never stamina rules.
    /// </summary>
    public readonly struct SettingsData
    {
        public readonly bool HeadBobEnabled;
        public readonly bool CameraShakeEnabled;
        public readonly bool FovBoostEnabled;
        public readonly bool SubtitlesEnabled;
        public readonly float MouseSensitivity;
        public readonly float Fov;

        public SettingsData(
            bool headBobEnabled = true,
            bool cameraShakeEnabled = true,
            bool fovBoostEnabled = true,
            bool subtitlesEnabled = true,
            float mouseSensitivity = 1f,
            float fov = 75f)
        {
            HeadBobEnabled = headBobEnabled;
            CameraShakeEnabled = cameraShakeEnabled;
            FovBoostEnabled = fovBoostEnabled;
            SubtitlesEnabled = subtitlesEnabled;
            MouseSensitivity = mouseSensitivity;
            Fov = fov;
        }

        public static SettingsData Defaults() => new SettingsData();
    }
}
