namespace Yumiwa.Domain
{
    /// <summary>
    /// Engine-agnostic checkpoint snapshot.
    /// Uses raw floats instead of UnityEngine types to honour Domain's noEngineReferences contract.
    /// Presentation-layer code packs/unpacks Unity transforms when calling Save/Load.
    /// </summary>
    [System.Serializable]
    public struct CheckpointData
    {
        public float PosX;
        public float PosY;
        public float PosZ;
        public float RotX;
        public float RotY;
        public float RotZ;
        public float RotW;
        public float Health;
        public float Stamina;
        public MovementState MovementState;
        public string ActiveScene;
        public long Timestamp;
        public CheckpointMilestone Milestone;
        public string SaveVersion;
        // ADR-0012: pending objective recoveries (itemIds) — null/empty means none. Version 2+.
        public string[] PendingRecoveredIds;
        // P1-M7: discovered hotspot keys "itemId|hotspotId" persisting Cancel progress across death. Version 3+.
        public string[] DiscoveredHotspotKeys;
    }
}