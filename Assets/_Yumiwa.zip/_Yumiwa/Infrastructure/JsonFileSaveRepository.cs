using System.IO;
using System.Threading.Tasks;
#if UNITY_5_3_OR_NEWER
using UnityEngine;
#endif
using Yumiwa.Domain;

namespace Yumiwa.Infrastructure
{
    /// <summary>
    /// File-backed save repository per GDD §52 — separate Chapter vs House stores.
    /// Atomic write via temp-file + Move; versioned via CheckpointData.SaveVersion.
    /// Non-blocking per ARCH §8: Awaitable.BackgroundThreadAsync on Unity, Task.Run fallback in EditMode tests.
    /// Infrastructure only, never referenced directly from Domain/Application beyond interface.
    /// </summary>
    public sealed class JsonFileSaveRepository : ISaveRepository
    {
        private const string ChapterKey = "yumiwa_chapter_save.json";
        private const string HouseKey = "yumiwa_house_save.json";
        private const string Version = "3"; // P1-M7 bump for DiscoveredHotspotKeys (was 2 for PendingRecoveredIds)

        private readonly string basePath;

        public JsonFileSaveRepository(string basePath = null)
        {
#if UNITY_5_3_OR_NEWER
            this.basePath = basePath ?? UnityEngine.Application.persistentDataPath;
#else
            this.basePath = basePath ?? Path.GetTempPath();
#endif
        }

        private string ChapterPath => Path.Combine(basePath, ChapterKey);
        private string HousePath => Path.Combine(basePath, HouseKey);

        [System.Serializable]
        private struct HouseWrapper
        {
            public CheckpointData Data;
            public CheckpointMilestone Milestone;
        }

        public bool HasChapterSave => File.Exists(ChapterPath);
        public bool HasHouseCheckpoint => File.Exists(HousePath);

        public void SaveChapter(CheckpointData data)
        {
            data.SaveVersion = Version;
            data.Timestamp = System.DateTimeOffset.UtcNow.ToUnixTimeSeconds();
#if UNITY_5_3_OR_NEWER
            WriteAtomicAsync(ChapterPath, JsonUtility.ToJson(data, true));
#else
            WriteAtomicAsync(ChapterPath, System.Text.Json.JsonSerializer.Serialize(data));
#endif
        }

        public CheckpointData LoadChapter()
        {
            if (!HasChapterSave)
                return default;
            var json = File.ReadAllText(ChapterPath);
#if UNITY_5_3_OR_NEWER
            var data = JsonUtility.FromJson<CheckpointData>(json);
#else
            var data = System.Text.Json.JsonSerializer.Deserialize<CheckpointData>(json);
#endif
            // Fallback for old saves without version
            if (string.IsNullOrEmpty(data.SaveVersion))
                data.SaveVersion = Version;
            return data;
        }

        public void SaveHouseCheckpoint(CheckpointData data, CheckpointMilestone milestone)
        {
            data.Milestone = milestone;
            data.SaveVersion = Version;
            data.Timestamp = System.DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            var wrapper = new HouseWrapper { Data = data, Milestone = milestone };
#if UNITY_5_3_OR_NEWER
            WriteAtomicAsync(HousePath, JsonUtility.ToJson(wrapper, true));
#else
            WriteAtomicAsync(HousePath, System.Text.Json.JsonSerializer.Serialize(wrapper));
#endif
        }

        public CheckpointData LoadHouseCheckpoint(out CheckpointMilestone milestone)
        {
            milestone = CheckpointMilestone.None;
            if (!HasHouseCheckpoint)
                return default;
            var json = File.ReadAllText(HousePath);
#if UNITY_5_3_OR_NEWER
            var wrapper = JsonUtility.FromJson<HouseWrapper>(json);
#else
            var wrapper = System.Text.Json.JsonSerializer.Deserialize<HouseWrapper>(json);
#endif
            milestone = wrapper.Milestone;
            return wrapper.Data;
        }

        public void ClearHouseCheckpoint()
        {
            if (File.Exists(HousePath))
                File.Delete(HousePath);
        }

        public void ClearAll()
        {
            ClearHouseCheckpoint();
            if (File.Exists(ChapterPath))
                File.Delete(ChapterPath);
        }

        private static void WriteAtomic(string path, string content)
        {
            string tmp = path + ".tmp";
            File.WriteAllText(tmp, content);
            if (File.Exists(path))
                File.Delete(path);
            File.Move(tmp, path);
        }

        private static async void WriteAtomicAsync(string path, string content)
        {
            string tmp = path + ".tmp";
#if UNITY_5_3_OR_NEWER
            // Unity 6000+: proper Awaitable background thread, fully non-blocking ARCH §8, awaited inside async void lifter
            try
            {
                await Awaitable.BackgroundThreadAsync();
                await File.WriteAllTextAsync(tmp, content);
                if (File.Exists(path)) File.Delete(path);
                File.Move(tmp, path);
            }
            catch (System.Exception e)
            {
                UnityEngine.Debug.LogWarning($"[Yumiwa] Save async failed {path}: {e.Message}");
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
            }
#else
            // EditMode test path: Task.Run fallback
            await Task.Run(async () =>
            {
                try
                {
                    await File.WriteAllTextAsync(tmp, content);
                    if (File.Exists(path)) File.Delete(path);
                    File.Move(tmp, path);
                }
                catch (System.Exception e)
                {
                    System.Console.WriteLine($"Save async failed {path}: {e.Message}");
                    try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                }
            });
#endif
        }
    }
}
