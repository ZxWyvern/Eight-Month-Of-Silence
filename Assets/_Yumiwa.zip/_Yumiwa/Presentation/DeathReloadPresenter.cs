using UnityEngine;
using VContainer;
using Yumiwa.Application;
using Yumiwa.Domain;
namespace Yumiwa.Presentation
{
    public sealed class DeathReloadPresenter : MonoBehaviour
    {
        private IHealthService health;
        private ICheckpointService checkpoint;
        private bool reloading;
        [Inject] public void Construct(IHealthService h, ICheckpointService c) { health=h; checkpoint=c; }
        void OnEnable() { if(health!=null) health.OnChanged += OnHealth; }
        void OnDisable() { if(health!=null) health.OnChanged -= OnHealth; }
        void OnHealth(HealthChangedEvent e)
        {
            if (e.Current > 0 || reloading) return;
            reloading = true;
            Invoke(nameof(DoReload), 1f);
        }
        void DoReload()
        {
            var data = checkpoint.LoadCheckpoint();
            if (!checkpoint.HasCheckpoint) { health.ResetHealth(); reloading=false; return; }
            var cc = GetComponent<CharacterController>();
            if (cc) cc.enabled=false;
            transform.position = new Vector3(data.PosX, data.PosY, data.PosZ);
            if (data.RotW != 0 || data.RotX !=0) transform.rotation = new Quaternion(data.RotX,data.RotY,data.RotZ,data.RotW);
            if (cc) cc.enabled=true;
            Physics.SyncTransforms();
            health.ResetHealth();
            reloading=false;
            Debug.Log($"[Yumiwa] Death reload to {data.ActiveScene} milestone {data.Milestone}", this);
        }
    }
}
