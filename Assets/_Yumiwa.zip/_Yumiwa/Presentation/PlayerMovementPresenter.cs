using UnityEngine;
using VContainer;
using Yumiwa.Application;
using Yumiwa.Domain;

namespace Yumiwa.Presentation
{
    /// <summary>Thin presenter mapping input and state to momentum-based CharacterController motion. Split via partial for SIZE-001.</summary>
    [RequireComponent(typeof(CharacterController))]
    public sealed partial class PlayerMovementPresenter : MonoBehaviour
    {
        [SerializeField] private Transform cameraTarget;
        [SerializeField] private Transform orbitPivot;
        [SerializeField] private Camera playerCamera;

        private CharacterController controller;
        private IMovementStateMachine machine;
        private IStaminaService stamina;
        private IPlayerInput input;
        private IWaterProvider water;
        private IEventBus bus;
        private System.Action<MovementConfigReloadedEvent> configReloadHandler;
        private System.Action<InspectionStartedEvent> inspectionStartedHandler;
        private System.Action<InspectionEndedEvent> inspectionEndedHandler;
        private System.Action<PlayerWoundedEvent> woundedHandler;
        private System.Action<PlayerHealedEvent> healedHandler;
        private bool controlsLocked;
        private IHealthService health;
        private bool sprinting;
        private bool crouching;
        private float cameraPitch;
        private bool wounded;
        private MovementConfigData movement;
        private StaminaConfigData staminaCfg;
        private SettingsData settings = SettingsData.Defaults();

        private Vector3 planarVelocity;
        private float verticalVelocity;

        private float coyoteTimer;
        private float jumpBufferTimer;
        private float airMaxSpeed;
        private float fallPeak;
        private bool wasGrounded = true;

        private float baseFov = 75f;
        private float bobPhase;
        private float dipOffset;
        private float dipVelocity;
        private float shakeTimer;
        private float landPunch;

        [Inject]
        public void Construct(
            IMovementStateMachine machine,
            IStaminaService stamina,
            IPlayerInput input,
            IWaterProvider water,
            IEventBus bus,
            IHealthService health,
            MovementConfigData movement,
            StaminaConfigData staminaCfg)
        {
            this.machine = machine;
            this.stamina = stamina;
            this.input = input;
            this.water = water;
            this.bus = bus;
            this.health = health;
            this.movement = movement;
            this.staminaCfg = staminaCfg;
            if (health != null) 
            {
                woundedHandler = _ => wounded = true;
                healedHandler = e => wounded = false;
                health.OnWounded += woundedHandler;
                health.OnHealed += healedHandler;
            }
        }

        public void ApplySettings(SettingsData s) => settings = s;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (playerCamera == null)
                playerCamera = GetComponentInChildren<Camera>();
            if (playerCamera != null)
                baseFov = playerCamera.fieldOfView;
        }

        public void WireCamera(Transform target, Transform pivot)
        {
            cameraTarget = target;
            orbitPivot = pivot;
        }

        public void ApplyMovementConfig(MovementConfigData data)
        {
            movement = data;
        }

        private void Start()
        {
            if (input == null || bus == null || machine == null || stamina == null)
            {
                UnityEngine.Debug.LogError("[Yumiwa] PlayerMovementPresenter injection missing.", this);
                enabled = false;
                return;
            }
            LockCursor();
            input.Enable();
            input.JumpPressed += OnJumpPressed;
            input.JumpReleased += OnJumpReleased;
            input.CrouchPressed += OnCrouchPressed;
            configReloadHandler = OnConfigReloaded;
            bus.Subscribe(configReloadHandler);
            inspectionStartedHandler = _ => controlsLocked = true;
            inspectionEndedHandler = _ => controlsLocked = false;
            bus.Subscribe(inspectionStartedHandler);
            bus.Subscribe(inspectionEndedHandler);
            if (playerCamera == null)
            {
                playerCamera = GetComponentInChildren<Camera>();
                if (playerCamera != null)
                    baseFov = playerCamera.fieldOfView;
            }
        }

        private void OnDisable()
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (input == null)
                return;
            input.JumpPressed -= OnJumpPressed;
            input.JumpReleased -= OnJumpReleased;
            input.CrouchPressed -= OnCrouchPressed;
            if (bus != null && configReloadHandler != null)
                bus.Unsubscribe(configReloadHandler);
            if (bus != null)
            {
                if (inspectionStartedHandler != null) bus.Unsubscribe(inspectionStartedHandler);
                if (inspectionEndedHandler != null) bus.Unsubscribe(inspectionEndedHandler);
            }
            if (health != null)
            {
                if (woundedHandler != null) health.OnWounded -= woundedHandler;
                if (healedHandler != null) health.OnHealed -= healedHandler;
            }
            input.Disable();
        }

        private void Update()
        {
            if (machine == null)
            {
                UnityEngine.Debug.LogWarning("[Yumiwa] PRESENTER_UNINJECTED");
                enabled = false;
                return;
            }
            if (controlsLocked)
                return;
            if (Cursor.lockState != CursorLockMode.Locked && IsClickPressed())
                LockCursor();
            float dt = Time.deltaTime;
            bool grounded = controller.isGrounded;
            if (!grounded && wasGrounded && TrySlopeSnap())
                grounded = true;

            HandleLandingTransition(grounded, dt);
            machine.SetGrounded(grounded);

            if (orbitPivot != null)
                orbitPivot.position = transform.position;
            ApplyLook(dt);
            machine.Tick(dt);
            UpdateSprint(dt, grounded);
            UpdateJump(dt, grounded);
            ApplyMovement(dt, grounded);
            ApplyCameraPose(dt, grounded);

            wasGrounded = grounded;
        }
    }
}
