using UnityEngine;
using UnityEngine.UI;
using VContainer;
using Yumiwa.Application;
using Yumiwa.Domain;

namespace Yumiwa.Presentation
{
    /// <summary>Prototype HUD for 2 Hands + 4 Pockets per GDD §03. Hand 1 = Right (slot 1), Hand 2 = Left (slot 0). Q swaps. Delegates HUD to InventoryHudView (SIZE-001).</summary>
    public sealed class InventoryPresenter : MonoBehaviour
    {
        [SerializeField] private Text hudText;
        [SerializeField] private Text reasonText;
        [SerializeField] private InventoryHudView hudView;

        private IInventoryService inventory;
        private PhysicalInventoryService physical;
        private IEventBus bus;
        private IPlayerInput playerInput;
        private IRecoveryPoint recovery;
        private CombatService combat;

        [Inject]
        public void Construct(IInventoryService inventory, IEventBus bus, IPlayerInput playerInput, IRecoveryPoint recovery = null, CombatService combat = null)
        {
            this.inventory = inventory;
            this.physical = inventory as PhysicalInventoryService;
            this.bus = bus;
            this.playerInput = playerInput;
            this.recovery = recovery;
            this.combat = combat;
        }

        private void Awake()
        {
            if (hudText == null) hudText = GetComponentInChildren<Text>(true);
            if (hudView == null) hudView = GetComponent<InventoryHudView>();
            if (hudView == null) hudView = GetComponentInChildren<InventoryHudView>(true);
            if (hudView == null)
            {
                var go = new GameObject("InventoryHudView");
                go.transform.SetParent(transform, false);
                hudView = go.AddComponent<InventoryHudView>();
                hudView.Bind(hudText, reasonText, GetComponent<Canvas>());
            }
            else
            {
                hudView.Bind(hudText, reasonText, GetComponent<Canvas>());
            }
        }

        private void OnEnable()
        {
            bus?.Subscribe<ItemPickedUpEvent>(OnPickedUp);
            bus?.Subscribe<InspectionTakeFailedEvent>(OnTakeFailed);
            bus?.Subscribe<AmmoChangedEvent>(OnAmmoChanged);
            if (playerInput != null)
            {
                playerInput.InventoryPressed += OnInventoryToggle;
                playerInput.SwapHandsPressed += OnSwapHands;
                playerInput.DropHeldPressed += OnDropHeld;
                playerInput.FirePressed += OnUseHand;
            }
            RefreshHud();
        }

        private void OnDisable()
        {
            bus?.Unsubscribe<ItemPickedUpEvent>(OnPickedUp);
            bus?.Unsubscribe<InspectionTakeFailedEvent>(OnTakeFailed);
            bus?.Unsubscribe<AmmoChangedEvent>(OnAmmoChanged);
            if (playerInput != null)
            {
                playerInput.InventoryPressed -= OnInventoryToggle;
                playerInput.SwapHandsPressed -= OnSwapHands;
                playerInput.DropHeldPressed -= OnDropHeld;
                playerInput.FirePressed -= OnUseHand;
            }
        }

        private void Update()
        {
            if (physical == null) return;
            var kb = UnityEngine.InputSystem.Keyboard.current;
            if (kb == null) return;
            bool shift = kb.leftShiftKey.isPressed || kb.rightShiftKey.isPressed;
            if (kb.digit1Key.wasPressedThisFrame) { if (shift) HandToPocket(1); else PocketToHand(2); }
            else if (kb.digit2Key.wasPressedThisFrame) { if (shift) HandToPocket(0); else PocketToHand(3); }
            else if (kb.digit3Key.wasPressedThisFrame) { if (shift) HandToPocket(0); else PocketToHand(4); }
            else if (kb.digit4Key.wasPressedThisFrame) { if (shift) HandToPocket(1); else PocketToHand(5); }
            if (kb.hKey.wasPressedThisFrame) HandToPocket(-1);
            if (kb.rKey.wasPressedThisFrame && combat != null) { combat.Reload(); hudView?.SetReason($"Reload {combat.Ammo}/{combat.MaxAmmo}"); RefreshHud(); }
        }

        private void HandToPocket(int handIndex)
        {
            if (physical == null) return;
            var slots = physical.GetSlots();
            if (handIndex == -1) { for (int i = 0; i < 2; i++) if (slots[i].IsOccupied) { handIndex = i; break; } if (handIndex < 0 || handIndex > 1 || !slots[handIndex].IsOccupied) return; }
            if (handIndex < 0 || handIndex > 1) return;
            var handItem = slots[handIndex].Item;
            if (!slots[handIndex].IsOccupied) return;
            if (!physical.TransferToPocket(handItem, out var reason)) Debug.LogWarning($"[Yumiwa] Hand→Pocket failed: {reason}", this);
            else Debug.Log($"[Yumiwa] Hand {(handIndex==1?"1 (Right)":"2 (Left)")} → Pocket: {handItem.ItemId}", this);
            RefreshHud();
        }

        private void PocketToHand(int pocketSlotIndex)
        {
            if (physical == null) return;
            var slots = physical.GetSlots();
            if (pocketSlotIndex < 0 || pocketSlotIndex >= slots.Length) return;
            var s = slots[pocketSlotIndex];
            if (!s.IsOccupied) return;
            if (!physical.QuickSwapToHand(s.Item.ItemId, out var reason)) Debug.LogWarning($"[Yumiwa] Pocket→Hand failed: {reason}", this);
            else Debug.Log($"[Yumiwa] Pocket {pocketSlotIndex-1} → Hand: {s.Item.ItemId}", this);
            RefreshHud();
        }

        private void OnUseHand()
        {
            if (physical != null && combat != null)
            {
                var sl = physical.GetSlots();
                for (int i = 0; i < 2; i++) if (sl[i].IsOccupied && sl[i].Item.ItemId == "pistol")
                {
                    if (!combat.TryFire()) { hudView?.SetReason("Click! Out of ammo (R)"); return; }
                    hudView?.SetReason($"Bang! {combat.Ammo}/{combat.MaxAmmo}"); RefreshHud(); return;
                }
            }
            if (physical == null) return;
            var s = physical.GetSlots();
            for (int i = 0; i < 2; i++) if (s[i].IsOccupied)
            {
                var item = s[i].Item;
                if (!physical.CanUse(item)) { hudView?.SetReason($"{item.ItemId} not in hand"); return; }
                bus?.Publish(new ItemUsedEvent(item.ItemId, (HandType)i));
                hudView?.SetReason($"Used {item.ItemId}"); RefreshHud(); return;
            }
        }

        private void OnAmmoChanged(AmmoChangedEvent e) { hudView?.SetReason($"Ammo {e.Current}/{e.Max}"); RefreshHud(); }
        private void OnPickedUp(ItemPickedUpEvent e) { RefreshHud(); hudView?.SetReason($"Picked {e.ItemId}"); }
        private void OnTakeFailed(InspectionTakeFailedEvent e) { hudView?.SetReason(e.Reason); Debug.LogWarning($"[Yumiwa] Inventory reject: {e.Reason}", this); }
        private void OnInventoryToggle() => hudView?.Toggle();
        private void OnSwapHands() { if (physical != null && !physical.SwapHands(out var r)) Debug.LogWarning($"[Yumiwa] SwapHands: {r}", this); RefreshHud(); }
        private void OnDropHeld()
        {
            if (physical == null) return;
            var slots = physical.GetSlots();
            for (int i = 0; i < 2; i++) if (slots[i].IsOccupied)
            {
                var item = slots[i].Item;
                if (item.IsObjectiveItem)
                {
                    if (!physical.DropWithRecovery(item, out var recovered, out var reason)) Debug.LogWarning($"[Yumiwa] DropWithRecovery failed: {reason}", this);
                    else Debug.Log($"[Yumiwa] Objective {recovered.ItemId} queued for auto-return.", this);
                }
                else
                {
                    if (!physical.Drop(item, out var reason)) Debug.LogWarning($"[Yumiwa] Drop failed: {reason}", this);
                    else Debug.Log($"[Yumiwa] Dropped {item.ItemId}.", this);
                }
                RefreshHud(); break;
            }
        }

        private void RefreshHud() => hudView?.Refresh(physical?.GetSlots(), combat);
        public void QuickSwap(string itemId) { if (physical != null && !physical.QuickSwapToHand(itemId, out var r)) Debug.LogWarning($"[Yumiwa] QuickSwap failed: {r}", this); else RefreshHud(); }
        public void SwapHands() { if (physical != null && !physical.SwapHands(out var r)) Debug.LogWarning($"[Yumiwa] SwapHands: {r}", this); }
        public void Drop(string itemId)
        {
            if (physical == null) return;
            var slot = System.Array.Find(physical.GetSlots(), s => s.IsOccupied && s.Item.ItemId == itemId);
            if (!slot.IsOccupied) return;
            var item = slot.Item;
            if (item.IsObjectiveItem)
            {
                if (!physical.DropWithRecovery(item, out _, out var reason)) Debug.LogWarning($"[Yumiwa] DropWithRecovery failed: {reason}", this);
            }
            else if (!physical.Drop(item, out var reason)) Debug.LogWarning($"[Yumiwa] Drop failed: {reason}", this);
            RefreshHud();
        }
        public void Refresh() => RefreshHud();
        public InventorySlot[] GetSlots() => physical?.GetSlots() ?? System.Array.Empty<InventorySlot>();
    }
}
