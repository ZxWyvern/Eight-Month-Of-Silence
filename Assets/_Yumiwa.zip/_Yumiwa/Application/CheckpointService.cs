using Yumiwa.Domain;

namespace Yumiwa.Application
{
    /// <summary>
    /// Split save per GDD §52: Chapter save (Ch1-2, non-checkpoint) vs House milestones (display-case/shovel/basement).
    /// Uses ISaveRepository for persistence; in-memory fallback keeps EditMode tests off disk.
    /// </summary>
    public sealed class CheckpointService : ICheckpointService
    {
        private CheckpointData? savedData;
        private CheckpointMilestone lastMilestone = CheckpointMilestone.None;
        private readonly IEventBus bus;
        private readonly ISaveRepository repo;
        private readonly IRecoveryPoint recovery;
        private readonly InspectionSessionService inspection;

        public CheckpointService(IEventBus bus, ISaveRepository repo = null, IRecoveryPoint recovery = null, InspectionSessionService inspection = null)
        {
            this.bus = bus;
            this.repo = repo;
            this.recovery = recovery;
            this.inspection = inspection;
        }

        public bool HasCheckpoint => savedData.HasValue || (repo != null && repo.HasHouseCheckpoint);
        public bool HasChapterSave => repo != null && repo.HasChapterSave;
        public CheckpointMilestone LastMilestone => lastMilestone;

        // Legacy ICheckpointService
        public void SaveCheckpoint(CheckpointData data)
        {
            // ADR-0012: persist pending recoveries
            if (recovery != null && recovery.PendingRecoveries.Count > 0)
            {
                var ids = new string[recovery.PendingRecoveries.Count];
                for (int i = 0; i < ids.Length; i++) ids[i] = recovery.PendingRecoveries[i].ItemId;
                data.PendingRecoveredIds = ids;
            }
            // P1-M7: persist hotspot progress
            if (inspection != null)
            {
                var keys = inspection.ExportDiscoveredKeys();
                data.DiscoveredHotspotKeys = keys.Length > 0 ? keys : null;
            }
            savedData = data;
            repo?.SaveHouseCheckpoint(data, data.Milestone);
        }

        public CheckpointData LoadCheckpoint()
        {
            CheckpointData result;
            if (repo != null && repo.HasHouseCheckpoint)
            {
                result = repo.LoadHouseCheckpoint(out var m);
                lastMilestone = m;
            }
            else
            {
                result = savedData ?? default;
            }
            // Rehydrate pending recoveries if any
            if (result.PendingRecoveredIds != null && recovery != null)
            {
                foreach (var id in result.PendingRecoveredIds)
                    if (!string.IsNullOrEmpty(id))
                        recovery.EnqueueRecovery(new ItemDefinition(id, id, "", 1, ItemKind.PhysicalTool, true));
                recovery.ResolveAll();
            }
            // P1-M7: rehydrate hotspot progress
            if (result.DiscoveredHotspotKeys != null && inspection != null)
                inspection.ImportDiscoveredKeys(result.DiscoveredHotspotKeys);
            return result;
        }

        public void ClearCheckpoint()
        {
            savedData = null;
            lastMilestone = CheckpointMilestone.None;
            repo?.ClearHouseCheckpoint();
        }

        // New API — GDD §52 milestones
        public void SaveHouseMilestone(CheckpointData data, CheckpointMilestone milestone)
        {
            data.Milestone = milestone;
            lastMilestone = milestone;
            if (recovery != null && recovery.PendingRecoveries.Count > 0)
            {
                var ids = new string[recovery.PendingRecoveries.Count];
                for (int i = 0; i < ids.Length; i++) ids[i] = recovery.PendingRecoveries[i].ItemId;
                data.PendingRecoveredIds = ids;
            }
            if (inspection != null)
            {
                var keys = inspection.ExportDiscoveredKeys();
                data.DiscoveredHotspotKeys = keys.Length > 0 ? keys : null;
            }
            savedData = data;
            repo?.SaveHouseCheckpoint(data, milestone);
            bus?.Publish(new CheckpointReachedEvent(milestone));
        }

        public void SaveChapter(CheckpointData data)
        {
            repo?.SaveChapter(data);
        }

        public CheckpointData LoadChapter()
        {
            return repo != null && repo.HasChapterSave ? repo.LoadChapter() : default;
        }

        public CheckpointData LoadHouseMilestone(out CheckpointMilestone milestone)
        {
            CheckpointData data;
            if (repo != null && repo.HasHouseCheckpoint)
                data = repo.LoadHouseCheckpoint(out milestone);
            else
            {
                milestone = lastMilestone;
                data = savedData ?? default;
            }
            if (data.PendingRecoveredIds != null && recovery != null)
            {
                foreach (var id in data.PendingRecoveredIds)
                    if (!string.IsNullOrEmpty(id))
                        recovery.EnqueueRecovery(new ItemDefinition(id, id, "", 1, ItemKind.PhysicalTool, true));
                recovery.ResolveAll();
            }
            if (data.DiscoveredHotspotKeys != null && inspection != null)
                inspection.ImportDiscoveredKeys(data.DiscoveredHotspotKeys);
            return data;
        }
    }

    public readonly struct CheckpointReachedEvent
    {
        public readonly CheckpointMilestone Milestone;
        public CheckpointReachedEvent(CheckpointMilestone m) => Milestone = m;
    }
}